//
//  LocalNotificationManager.swift
//  List
//
//  Created by Oleksii Kolakovskyi on 10/19/19.
//  Copyright © 2019 Aleksey. All rights reserved.
//

import Foundation
import UserNotifications

class UNUserNotificationCenter {


    
}
